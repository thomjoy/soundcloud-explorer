## 0.5.0 / 2013-08-04

  * upgrade to Backbone 1.0.0

## 0.3.0 / 2012-05-06

  * Checkup localStorage quota
  * fixed bugs with full-sync
  * added auto runs incremental sync and manual sync on fetch

## 0.2.0 / 2012-04-13

  * First public release.
  * Fixed bugs, added comments and documentation, refactoring
  * added `onLine()` method
  * added `autoPush` option
  * upgrade to Backbone 0.9.2

## 0.1.0 / 2012-03-11

  * Library was extracted from project http://saveideanow.com
