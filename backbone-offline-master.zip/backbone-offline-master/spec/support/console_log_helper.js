window.l = function(value) { console.log(value) }
